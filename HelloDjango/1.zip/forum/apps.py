from django.apps import AppConfig


class ForumAppConfig(AppConfig):
    name = 'forum'
    verbose_name = 'Форум'
