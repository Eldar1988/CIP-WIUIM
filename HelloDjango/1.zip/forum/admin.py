from django.contrib import admin
from .models import Theme, Comment


@admin.register(Theme)
class ThemeAdmin(admin.ModelAdmin):
    list_display = ('title', 'author', 'like', 'dislike', 'pub_date')


@admin.register(Comment)
class CommentAdmin(admin.ModelAdmin):
    list_display = ('name', 'theme', 'text', 'answer_for', 'like', 'dislike', 'pub_date')