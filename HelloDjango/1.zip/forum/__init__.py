default_app_config = "forum.apps.ForumAppConfig"
