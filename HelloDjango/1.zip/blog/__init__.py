default_app_config = "blog.apps.BlogAppConfig"
