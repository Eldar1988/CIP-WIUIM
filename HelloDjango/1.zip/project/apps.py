from django.apps import AppConfig


class ProjectAppConfig(AppConfig):
    name = 'project'
    verbose_name = 'Проекты'
