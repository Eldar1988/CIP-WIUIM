from django.shortcuts import render
from django.core.paginator import Paginator
from django.views.generic import View

from .models import Data, Benefits, Structure, Questions, Review, Project


class ProjectList(View):
    """Вывод списка проектов"""
    def get(self, request):
        projects = Project.objects.filter(draft=True)

        return render(request, 'project/project_list.html', {
            'projects': projects,
            })


class ProjectDetail(View):
    """Страница проекта"""
    def get(self, request, slug):
        project = Project.objects.get(slug=slug)

        return render(request, 'project/project_detail.html', {
            'project': project,
        })


class StructureDetail(View):
    """Элемент структуры проекта"""
    def get(self, request, slug):
        structure = Structure.objects.get(slug=slug)

        return render(request, 'project/structure_detail.html', {
            'structure': structure,
        })

