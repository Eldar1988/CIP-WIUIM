from django.contrib import admin
from .models import Project, Data, Benefits, Structure, Questions, Review


@admin.register(Project)
class ThemeAdmin(admin.ModelAdmin):
    list_display = ('name', 'company', 'user', 'order', 'pub_date', 'show_count')


@admin.register(Data)
class ThemeAdmin(admin.ModelAdmin):
    list_display = ('name', 'number')


@admin.register(Benefits)
class ThemeAdmin(admin.ModelAdmin):
    list_display = ('title',)


@admin.register(Structure)
class ThemeAdmin(admin.ModelAdmin):
    list_display = ('title', 'order', 'slug')


@admin.register(Questions)
class ThemeAdmin(admin.ModelAdmin):
    list_display = ('question', 'answer', 'order')


@admin.register(Review)
class ThemeAdmin(admin.ModelAdmin):
    list_display = ('name', 'position')
