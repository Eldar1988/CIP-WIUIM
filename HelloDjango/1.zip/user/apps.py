from django.apps import AppConfig


class UserAppConfig(AppConfig):
    name = 'user'
    verbose_name = 'Профили и компании'
