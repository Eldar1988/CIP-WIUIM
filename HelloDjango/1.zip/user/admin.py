from django.contrib import admin
from .models import Profile, Company


@admin.register(Profile)
class ProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'name', 'main_phone', 'mail', 'register_date')


@admin.register(Company)
class CompanyAdmin(admin.ModelAdmin):
    list_display = ('user', 'name', 'main_phone', 'mail', 'register_date')